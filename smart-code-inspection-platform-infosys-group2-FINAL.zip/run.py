import uvicorn
from backend.app.config import HOST, PORT

def main():
    print("==========================================================================")
    print(" Smart Code Inspection Platform with Vulnerability Detection System")
    print(" Group 2 — Infosys Internship Project")
    print(f" Server running at: http://{HOST}:{PORT}")
    print(" Open http://localhost:5000 in your browser.")
    print("==========================================================================")
    uvicorn.run("backend.app.main:app", host=HOST, port=PORT, reload=True)

if __name__ == "__main__":
    main()
