import io
from pathlib import Path
from typing import Optional, List, Dict, Any
from fastapi import FastAPI, HTTPException, Query, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from .config import PORT, HOST
from .models.schemas import (
    ValidateRequest,
    AnalyzeRequest,
    ChatRequest,
    SubmissionResult,
    AnalysisRecord,
)
from .services.submission_service import validate_submission
from .agents.orchestrator import Orchestrator
from .agents.conversational_code_assistant import ConversationalCodeAssistant
from .rag.knowledge_base import KNOWLEDGE_BASE
from .rag.rag_engine import retrieve
from .samples.sample_data import SAMPLES
from .report.generator import (
    generate_markdown_report,
    generate_json_report,
    generate_pdf_report,
)
from .database import (
    init_db,
    save_analysis,
    get_analysis,
    list_analyses,
    delete_analysis,
    clear_all_analyses,
)

# Initialize SQLite database schema
init_db()

app = FastAPI(
    title="Smart Code Inspection Platform",
    description="Multi-agent vulnerability detection and code inspection platform — Group 2",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

orchestrator = Orchestrator()
assistant = ConversationalCodeAssistant()

frontend_dir = Path(__file__).resolve().parent.parent.parent / "frontend"


# ---------------- API Routes ----------------

@app.post("/api/validate", response_model=SubmissionResult)
def api_validate(req: ValidateRequest):
    return validate_submission(req.code, req.filename, req.language)


@app.post("/api/analyze", response_model=AnalysisRecord)
def api_analyze(req: AnalyzeRequest):
    if not req.code or not req.code.strip():
        raise HTTPException(status_code=400, detail="Submission code cannot be empty.")
    try:
        record = orchestrator.run_pipeline(
            code=req.code[:40000],
            filename=req.filename or "snippet.py",
            requested_language=req.language or "Auto-detect",
            api_key=req.apiKey,
        )
        return record
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis pipeline error: {str(e)}")


@app.get("/api/analyses", response_model=List[AnalysisRecord])
def api_list_analyses():
    return list_analyses()


@app.get("/api/analyses/{record_id}", response_model=AnalysisRecord)
def api_get_analysis(record_id: str):
    record = get_analysis(record_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")
    return record


@app.delete("/api/analyses/{record_id}")
def api_delete_analysis(record_id: str):
    deleted = delete_analysis(record_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Analysis record not found.")
    return {"success": True, "message": "Analysis deleted."}


@app.delete("/api/analyses")
def api_clear_analyses():
    clear_all_analyses()
    return {"success": True, "message": "All analyses cleared."}


@app.post("/api/chat")
def api_chat(req: ChatRequest):
    if not req.question or not req.question.strip():
        raise HTTPException(status_code=400, detail="Question cannot be empty.")
    try:
        result = assistant.answer(
            question=req.question.strip(),
            history=req.history,
            analysis_context=req.analysisContext,
            api_key=req.apiKey,
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Assistant error: {str(e)}")


@app.get("/api/samples")
def api_get_samples():
    return SAMPLES


@app.get("/api/knowledge")
def api_get_knowledge(q: Optional[str] = Query(None)):
    if not q or not q.strip():
        return KNOWLEDGE_BASE
    query = q.strip().lower()
    filtered = [
        doc for doc in KNOWLEDGE_BASE
        if query in doc["title"].lower()
        or any(query in tag.lower() for tag in doc["tags"])
        or query in doc["body"].lower()
    ]
    return filtered


@app.get("/api/stats")
def api_get_stats():
    analyses = list_analyses()
    if not analyses:
        return {
            "totalAnalyses": 0,
            "security": 0,
            "quality": 0,
            "maintainability": 0,
            "health": 0,
            "counts": [
                {"severity": "Critical", "count": 0},
                {"severity": "High", "count": 0},
                {"severity": "Medium", "count": 0},
                {"severity": "Low", "count": 0},
            ],
            "totalFindings": 0,
        }

    n = len(analyses)
    avg_sec = round(sum(a.metrics.securityScore for a in analyses) / n)
    avg_qual = round(sum(a.metrics.qualityScore for a in analyses) / n)
    avg_maint = round(sum(a.metrics.maintainabilityScore for a in analyses) / n)
    avg_health = round(sum(a.metrics.overallHealth for a in analyses) / n)

    counts_map = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
    for a in analyses:
        for f in a.securityFindings + a.qualityFindings:
            if f.severity in counts_map:
                counts_map[f.severity] += 1

    counts = [{"severity": k, "count": v} for k, v in counts_map.items()]
    total_findings = sum(counts_map.values())

    return {
        "totalAnalyses": n,
        "security": avg_sec,
        "quality": avg_qual,
        "maintainability": avg_maint,
        "health": avg_health,
        "counts": counts,
        "totalFindings": total_findings,
    }


@app.get("/api/reports/{record_id}/markdown")
def api_report_markdown(record_id: str):
    record = get_analysis(record_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")
    md = generate_markdown_report(record)
    return Response(
        content=md,
        media_type="text/markdown",
        headers={"Content-Disposition": f'attachment; filename="code-review-{record.submission.filename}.md"'},
    )


@app.get("/api/reports/{record_id}/json")
def api_report_json(record_id: str):
    record = get_analysis(record_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")
    data = generate_json_report(record)
    return Response(
        content=data,
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="code-review-{record.submission.filename}.json"'},
    )


@app.get("/api/reports/{record_id}/pdf")
def api_report_pdf(record_id: str):
    record = get_analysis(record_id)
    if not record:
        raise HTTPException(status_code=404, detail="Analysis record not found.")
    try:
        pdf_bytes = generate_pdf_report(record)
        return StreamingResponse(
            io.BytesIO(pdf_bytes),
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="code-review-{record.submission.filename}.pdf"'},
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"PDF generation failed: {str(e)}")


# ---------------- Frontend Static & Route Serving ----------------

if frontend_dir.exists():
    app.mount("/css", StaticFiles(directory=str(frontend_dir / "css")), name="css")
    app.mount("/js", StaticFiles(directory=str(frontend_dir / "js")), name="js")


@app.get("/")
def serve_index():
    index_file = frontend_dir / "index.html"
    if index_file.exists():
        return FileResponse(str(index_file))
    return {"message": "Smart Code Inspection Platform API is running."}


@app.get("/dashboard")
@app.get("/dashboard.html")
def serve_dashboard():
    return FileResponse(str(frontend_dir / "dashboard.html"))


@app.get("/analyze")
@app.get("/analyze.html")
@app.get("/analysis.html")
def serve_analyze():
    return FileResponse(str(frontend_dir / "analysis.html"))


@app.get("/results")
@app.get("/results.html")
@app.get("/findings.html")
def serve_findings():
    return FileResponse(str(frontend_dir / "findings.html"))


@app.get("/chat")
@app.get("/chat.html")
@app.get("/assistant.html")
def serve_assistant():
    return FileResponse(str(frontend_dir / "assistant.html"))


@app.get("/knowledge")
@app.get("/knowledge.html")
@app.get("/knowledge-base.html")
def serve_knowledge():
    return FileResponse(str(frontend_dir / "knowledge-base.html"))


@app.get("/reports")
@app.get("/reports.html")
def serve_reports():
    return FileResponse(str(frontend_dir / "reports.html"))


@app.get("/history")
@app.get("/history.html")
def serve_history():
    return FileResponse(str(frontend_dir / "history.html"))


def start():
    import uvicorn
    uvicorn.run("backend.app.main:app", host=HOST, port=PORT, reload=True)


if __name__ == "__main__":
    start()
