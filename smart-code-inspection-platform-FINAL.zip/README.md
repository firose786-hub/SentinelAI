# Smart Code Inspection Platform with Vulnerability Detection System — Group 2

An automated multi-agent code inspection and vulnerability detection platform built with Python agents, FastAPI backend, and Vanilla HTML/CSS/JavaScript frontend.

## Architecture Overview

- **Backend**: Python 3.11+ / FastAPI
- **Frontend**: Plain HTML5, CSS3 (Warm Sentinel Design System), Vanilla JavaScript (ES6+ fetch API)
- **Multi-Agent Engine**:
  1. `code_analysis_agent.py`: AST-level code smells, design anti-patterns, radon cyclomatic complexity, and maintainability index.
  2. `security_vulnerability_agent.py`: AST security checks for OWASP Top 10 (A01–A10), CWE-89 (SQLi), CWE-78 (Command Injection), CWE-798 (Credentials in source with Shannon entropy), CWE-327 (Weak Cryptography/MD5), CWE-95 (Eval/Exec), CWE-502 (Deserialization), and CWE-338 (Weak PRNG).
  3. `remediation_agent.py`: Root-cause analysis, actionable fixes, secure coding best practices, and compilable corrected code snippets. Integrated with official Google Gemini SDK.
  4. `pr_summary_agent.py`: PR-style review summary, deterministic score calculation (Security, Quality, Maintainability, Overall Health), severity distribution breakdown, and review verdict (`Approve`, `Approve with suggestions`, `Request changes`, `Block`).
  5. `conversational_code_assistant.py`: Conversational RAG assistant answering follow-up questions grounded in the indexed secure coding knowledge base with source citations.
  6. `orchestrator.py`: Multi-agent pipeline coordinator running analysis and security scanning in parallel.
- **RAG Engine**: Sentence-aligned chunking, TF-IDF vector index, and cosine similarity retrieval over 17 secure coding and OWASP documents.
- **Reports**: ReportLab PDF generator, Markdown review reports, and JSON export.
- **Persistence**: SQLite database (`data/analyses.db`).

## Getting Started

### 1. Prerequisites
- Python 3.11+

### 2. Install Dependencies
```bash
cd backend
python -m pip install -r requirements.txt
```

### 3. Configure Environment (Optional)
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Add your optional `GEMINI_API_KEY` for semantic AI enhancement. When omitted, the platform runs deterministically using local knowledge base grounding.

### 4. Start the Application
```bash
python run.py
```
Open your browser and navigate to `http://localhost:5000`.

### 5. Run Tests
```bash
pytest backend/tests -v
```

## Milestone Deliverables

- **Milestone 1**: Code submission module, language detection, syntax validation with Python AST and Java parser, RAG knowledge base.
- **Milestone 2**: Multi-agent static analysis, Code Analysis Agent with radon metrics, Security Vulnerability Agent with OWASP/CWE classification.
- **Milestone 3**: Remediation Agent, PR Summary Agent with score calculation, Conversational Code Assistant with citation grounding, ReportLab PDF generation.
- **Milestone 4**: End-to-end integration, persistent SQLite storage, responsive warm paper terminal UI, complete test suite.
