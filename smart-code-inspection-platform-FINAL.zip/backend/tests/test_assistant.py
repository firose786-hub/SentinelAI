from backend.app.agents.conversational_code_assistant import ConversationalCodeAssistant


def test_assistant_answers_with_citations():
    assistant = ConversationalCodeAssistant()
    res = assistant.answer("Why is MD5 unsafe for password hashing?")
    assert "answer" in res
    assert "citations" in res
    assert len(res["answer"]) > 20
    assert len(res["citations"]) > 0
    assert any("cryptographic" in c.lower() or "owasp" in c.lower() for c in res["citations"])


def test_assistant_with_analysis_context():
    assistant = ConversationalCodeAssistant()
    res = assistant.answer(
        question="How should I fix the SQL injection?",
        analysis_context="File banking_service.py has Critical SQL injection on line 30.",
    )
    assert len(res["answer"]) > 20
    assert len(res["citations"]) > 0
