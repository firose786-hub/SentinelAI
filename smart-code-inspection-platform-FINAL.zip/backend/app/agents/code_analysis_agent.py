import ast
import re
from typing import List, Dict, Any, Tuple
from radon.complexity import cc_visit
from radon.metrics import mi_visit
from ..models.schemas import QualityFinding, Severity


class PythonQualityVisitor(ast.NodeVisitor):
    def __init__(self, lines: List[str]):
        self.lines = lines
        self.findings: List[Dict[str, Any]] = []
        self.seen_rules = set()

    def visit_ExceptHandler(self, node: ast.ExceptHandler):
        line_num = node.lineno
        # Check broad exception
        if node.type is None or (isinstance(node.type, ast.Name) and node.type.id in ("Exception", "BaseException")):
            if "broad-except" not in self.seen_rules:
                self.seen_rules.add("broad-except")
                self.findings.append({
                    "title": "Overly broad exception handling",
                    "detail": "Catching every exception hides real failures and complicates debugging.",
                    "severity": "Medium",
                    "category": "Error handling",
                    "line": line_num,
                })

        # Check empty or pass-only handler
        if len(node.body) == 1 and isinstance(node.body[0], ast.Pass):
            if "empty-catch" not in self.seen_rules:
                self.seen_rules.add("empty-catch")
                self.findings.append({
                    "title": "Silently swallowed exception",
                    "detail": "An empty handler discards the error without logging or recovery.",
                    "severity": "Medium",
                    "category": "Error handling",
                    "line": line_num,
                })
        elif len(node.body) == 0:
            if "empty-catch" not in self.seen_rules:
                self.seen_rules.add("empty-catch")
                self.findings.append({
                    "title": "Silently swallowed exception",
                    "detail": "An empty handler discards the error without logging or recovery.",
                    "severity": "Medium",
                    "category": "Error handling",
                    "line": line_num,
                })

        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom):
        if any(alias.name == "*" for alias in node.names):
            if "star-import" not in self.seen_rules:
                self.seen_rules.add("star-import")
                self.findings.append({
                    "title": "Wildcard import",
                    "detail": "Wildcard imports pollute the namespace and hide dependencies.",
                    "severity": "Low",
                    "category": "Design",
                    "line": node.lineno,
                })
        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef):
        # Check function length
        if hasattr(node, "end_lineno") and node.end_lineno:
            func_len = node.end_lineno - node.lineno + 1
            if func_len > 40 and "long-method" not in self.seen_rules:
                self.seen_rules.add("long-method")
                self.findings.append({
                    "title": "Long method / low decomposition",
                    "detail": f"Function '{node.name}' spans {func_len} lines; extract cohesive units.",
                    "severity": "Medium",
                    "category": "Complexity",
                    "line": node.lineno,
                })
        self.generic_visit(node)

    def visit_Constant(self, node: ast.Constant):
        if isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
            if node.value >= 1000 and "magic-number" not in self.seen_rules:
                # Avoid flagging common port 80/443/8080 or docstring lineno
                self.seen_rules.add("magic-number")
                self.findings.append({
                    "title": "Magic number in logic",
                    "detail": f"Unnamed numeric literal {node.value} obscures intent; extract a named constant.",
                    "severity": "Low",
                    "category": "Readability",
                    "line": getattr(node, "lineno", None),
                })
        self.generic_visit(node)


def analyze_python_quality(code: str) -> List[QualityFinding]:
    findings: List[QualityFinding] = []
    lines = code.split("\n")

    # AST visitor analysis
    try:
        tree = ast.parse(code)
        visitor = PythonQualityVisitor(lines)
        visitor.visit(tree)
        for raw in visitor.findings:
            findings.append(QualityFinding(
                id=f"q{len(findings) + 1}",
                title=raw["title"],
                detail=raw["detail"],
                severity=raw["severity"],
                category=raw["category"],
                line=raw.get("line"),
                agent="Code Analysis Agent"
            ))
    except Exception:
        pass

    # Comment & line-level smell inspection (e.g. TODO/FIXME markers)
    seen_todo = False
    for idx, line in enumerate(lines, 1):
        trimmed = line.strip()
        if re.search(r"\b(TODO|FIXME|HACK|XXX)\b", line):
            if not seen_todo and (trimmed.startswith("#") or "//" in line or "/*" in line):
                seen_todo = True
                findings.append(QualityFinding(
                    id=f"q{len(findings) + 1}",
                    title="Unresolved TODO/FIXME marker",
                    detail="Outstanding work markers left in shipped code.",
                    severity="Low",
                    category="Maintainability",
                    line=idx,
                    agent="Code Analysis Agent"
                ))

    # Deep nesting check
    max_indent = max((len(re.match(r"^[ \t]+", l).group(0)) for l in lines if re.match(r"^[ \t]+", l)), default=0)
    if max_indent >= 20 and not any(f.title == "Deep nesting detected" for f in findings):
        findings.append(QualityFinding(
            id=f"q{len(findings) + 1}",
            title="Deep nesting detected",
            detail=f"Indentation reaches {max_indent} columns; use guard clauses to flatten control flow.",
            severity="Medium",
            category="Complexity",
            line=None,
            agent="Code Analysis Agent"
        ))

    return findings


def analyze_java_quality(code: str) -> List[QualityFinding]:
    findings: List[QualityFinding] = []
    lines = code.split("\n")

    # Use javalang parser for AST analysis
    try:
        import javalang
        tree = javalang.parse.parse(code)

        seen_rules = set()
        for path, node in tree:
            if isinstance(node, javalang.tree.CatchClause):
                # Check for broad or empty catch
                param = node.parameter
                type_name = param.types[0] if (param and param.types) else ""
                is_broad = type_name in ("Exception", "Throwable")
                is_empty = not node.block or len(node.block) == 0

                line_no = node.position.line if node.position else None

                if is_broad and "broad-except" not in seen_rules:
                    seen_rules.add("broad-except")
                    findings.append(QualityFinding(
                        id=f"q{len(findings) + 1}",
                        title="Overly broad exception handling",
                        detail="Catching every exception hides real failures and complicates debugging.",
                        severity="Medium",
                        category="Error handling",
                        line=line_no,
                        agent="Code Analysis Agent"
                    ))

                if is_empty and "empty-catch" not in seen_rules:
                    seen_rules.add("empty-catch")
                    findings.append(QualityFinding(
                        id=f"q{len(findings) + 1}",
                        title="Silently swallowed exception",
                        detail="An empty handler discards the error without logging or recovery.",
                        severity="Medium",
                        category="Error handling",
                        line=line_no,
                        agent="Code Analysis Agent"
                    ))

            elif isinstance(node, javalang.tree.Import):
                if node.wildcard and "star-import" not in seen_rules:
                    seen_rules.add("star-import")
                    findings.append(QualityFinding(
                        id=f"q{len(findings) + 1}",
                        title="Wildcard import",
                        detail="Wildcard imports pollute the namespace and hide dependencies.",
                        severity="Low",
                        category="Design",
                        line=node.position.line if node.position else None,
                        agent="Code Analysis Agent"
                    ))
    except Exception:
        # Fallback lexical check for Java
        seen_rules = set()
        for idx, line in enumerate(lines, 1):
            if re.search(r"catch\s*\(\s*(Exception|Throwable)\s+\w+\s*\)", line) and "broad-except" not in seen_rules:
                seen_rules.add("broad-except")
                findings.append(QualityFinding(
                    id=f"q{len(findings) + 1}",
                    title="Overly broad exception handling",
                    detail="Catching every exception hides real failures and complicates debugging.",
                    severity="Medium",
                    category="Error handling",
                    line=idx,
                    agent="Code Analysis Agent"
                ))
            if re.search(r"catch\s*\([^)]*\)\s*\{\s*\}", line) and "empty-catch" not in seen_rules:
                seen_rules.add("empty-catch")
                findings.append(QualityFinding(
                    id=f"q{len(findings) + 1}",
                    title="Silently swallowed exception",
                    detail="An empty handler discards the error without logging or recovery.",
                    severity="Medium",
                    category="Error handling",
                    line=idx,
                    agent="Code Analysis Agent"
                ))

    # Check TODOs in comments
    seen_todo = False
    for idx, line in enumerate(lines, 1):
        if re.search(r"\b(TODO|FIXME|HACK|XXX)\b", line) and ("//" in line or "/*" in line):
            if not seen_todo:
                seen_todo = True
                findings.append(QualityFinding(
                    id=f"q{len(findings) + 1}",
                    title="Unresolved TODO/FIXME marker",
                    detail="Outstanding work markers left in shipped code.",
                    severity="Low",
                    category="Maintainability",
                    line=idx,
                    agent="Code Analysis Agent"
                ))

    return findings


def estimate_complexity(code: str, language: str = "Python") -> Dict[str, Any]:
    # Calculate cyclomatic complexity using radon for Python
    if language == "Python":
        try:
            blocks = cc_visit(code)
            if blocks:
                avg_cc = sum(b.complexity for b in blocks) / len(blocks)
                label = "High" if avg_cc > 12 else "Medium" if avg_cc > 6 else "Low"
                return {"score": round(avg_cc, 1), "label": label}
        except Exception:
            pass

    # Generic branch calculation
    branches = len(re.findall(r"\b(if|for|while|case|catch|except|elif|&&|\|\||\?)\b", code))
    functions = max(1, len(re.findall(r"^[ \t]*(def |function |public |private |protected )", code, re.MULTILINE)))
    per_function = branches / functions
    label = "High" if per_function > 12 else "Medium" if per_function > 6 else "Low"
    return {"score": round(per_function, 1), "label": label}


class CodeAnalysisAgent:
    """Milestone 2 — Code Analysis Agent."""

    def __init__(self):
        self.name = "Code Analysis Agent"

    def analyze(self, code: str, language: str) -> Tuple[List[QualityFinding], Dict[str, Any]]:
        if language == "Python":
            findings = analyze_python_quality(code)
        elif language == "Java":
            findings = analyze_java_quality(code)
        else:
            findings = analyze_python_quality(code)

        complexity = estimate_complexity(code, language)
        return findings, complexity
