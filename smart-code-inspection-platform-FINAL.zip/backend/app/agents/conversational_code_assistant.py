import json
import re
from typing import List, Dict, Any, Optional
from ..rag.rag_engine import retrieve, format_context, citations_of
from ..config import GEMINI_API_KEY, GEMINI_MODEL


class ConversationalCodeAssistant:
    """Milestone 3 — Conversational Code Assistant (RAG)."""

    def __init__(self):
        self.name = "Conversational Code Assistant"

    def _answer_with_gemini(
        self,
        question: str,
        history: List[Dict[str, str]],
        context: str,
        analysis_context: Optional[str] = None,
    ) -> Optional[str]:
        if not GEMINI_API_KEY:
            return None

        try:
            from google import genai
            client = genai.Client(api_key=GEMINI_API_KEY)

            system_instruction = (
                "You are the Conversational Code Assistant for the Smart Code Inspection Platform.\n"
                "Answer questions about flagged code findings, OWASP vulnerabilities, and secure coding practices.\n"
                "Ground your answers strictly in the retrieved knowledge base documents and the analysis context.\n"
                "Cite sources using [1], [2] annotations corresponding to the retrieved context.\n"
                "Keep answers direct, informative, and under 250 words. Provide fenced code examples when helpful."
            )

            history_lines = []
            for m in history[-6:]:
                role = "Developer" if m.get("role") == "user" else "Assistant"
                history_lines.append(f"{role}: {m.get('content', '')}")

            prompt = (
                f"{system_instruction}\n\n"
                f"Retrieved Secure Coding Knowledge Base:\n{context}\n\n"
                f"Current Analysis Context:\n{analysis_context or 'No specific analysis loaded.'}\n\n"
                f"Conversation History:\n" + "\n".join(history_lines) + f"\n\nDeveloper: {question}\nAssistant:"
            )

            response = client.models.generate_content(
                model=GEMINI_MODEL,
                contents=prompt,
            )

            return response.text.strip() if response.text else None
        except Exception:
            return None

    def _synthesize_local_response(
        self,
        question: str,
        retrieved_results: List[Dict[str, Any]],
        analysis_context: Optional[str] = None,
    ) -> str:
        if not retrieved_results:
            return (
                "I searched the Secure Coding Knowledge Base, but did not find matching guidelines for your query. "
                "Please ensure all user inputs are validated, secrets are loaded from environment variables, "
                "and parameterised queries are used for database operations."
            )

        top_chunk = retrieved_results[0]["chunk"]
        title = top_chunk["title"]
        source = top_chunk["source"]
        text = top_chunk["text"]

        lines = [
            f"Based on **{title}** ({source}) [1]:\n",
            f"{text}\n",
        ]

        if len(retrieved_results) > 1:
            second_chunk = retrieved_results[1]["chunk"]
            lines.append(f"Additionally, **{second_chunk['title']}** ({second_chunk['source']}) [2] provides guidance:")
            lines.append(f"{second_chunk['text']}\n")

        if analysis_context:
            lines.append(f"Regarding your current inspection ({analysis_context}): ensure the highlighted remediations are applied before merging.")

        return "\n".join(lines)

    def answer(
        self,
        question: str,
        history: Optional[List[Dict[str, str]]] = None,
        analysis_context: Optional[str] = None,
    ) -> Dict[str, Any]:
        history = history or []
        retrieved = retrieve(question, k=5)
        context = format_context(retrieved)
        citations = citations_of(retrieved)

        # 1. Try Gemini if configured
        gemini_answer = self._answer_with_gemini(question, history, context, analysis_context)
        if gemini_answer:
            return {
                "answer": gemini_answer,
                "citations": citations,
            }

        # 2. Local knowledge-grounded synthesis
        answer = self._synthesize_local_response(question, retrieved, analysis_context)
        return {
            "answer": answer,
            "citations": citations,
        }
