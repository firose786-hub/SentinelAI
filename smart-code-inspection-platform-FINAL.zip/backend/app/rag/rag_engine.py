import math
import re
from typing import List, Dict, Any, Tuple, Set
from .knowledge_base import KNOWLEDGE_BASE

DIM = 384
CHUNK_TARGET_CHARS = 520
CHUNK_OVERLAP_SENTENCES = 1

STOPWORDS: Set[str] = set(
    "a an and are as at be by for from has have in is it its of on or that the to with which when this these those not no do does can may".split()
)


def tokenize(text: str) -> List[str]:
    cleaned = re.sub(r"[^a-z0-9_+#.-]+", " ", text.lower())
    tokens = cleaned.split()
    return [t for t in tokens if len(t) > 1 and t not in STOPWORDS]


def _hash_token(token: str) -> int:
    h = 2166136261
    for ch in token:
        h ^= ord(ch)
        h = (h * 16777619) & 0xFFFFFFFF
    return h % DIM


def chunk_document(doc: Dict[str, Any]) -> List[Dict[str, Any]]:
    body = re.sub(r"\n+", " ", doc["body"])
    sentences = [s.strip() for s in re.split(r"(?<=[.;])\s+", body) if s.strip()]

    chunks = []
    buffer: List[str] = []
    length = 0

    def flush():
        nonlocal buffer, length
        if not buffer:
            return
        chunk_text = f"{doc['title']}. {' '.join(buffer)}"
        chunks.append({
            "id": f"{doc['id']}#{len(chunks)}",
            "docId": doc["id"],
            "title": doc["title"],
            "source": doc["source"],
            "tags": doc["tags"],
            "text": chunk_text,
        })
        buffer = buffer[-CHUNK_OVERLAP_SENTENCES:]
        length = sum(len(s) for s in buffer)

    for sentence in sentences:
        buffer.append(sentence)
        length += len(sentence)
        if length >= CHUNK_TARGET_CHARS:
            flush()

    if buffer:
        chunk_text = f"{doc['title']}. {' '.join(buffer)}"
        chunks.append({
            "id": f"{doc['id']}#{len(chunks)}",
            "docId": doc["id"],
            "title": doc["title"],
            "source": doc["source"],
            "tags": doc["tags"],
            "text": chunk_text,
        })

    return chunks


def _embed(tokens: List[str], idf: Dict[str, float]) -> List[float]:
    vec = [0.0] * DIM
    counts: Dict[str, int] = {}
    for t in tokens:
        counts[t] = counts.get(t, 0) + 1

    default_idf = math.log(1.0 + len(KNOWLEDGE_BASE))
    for token, count in counts.items():
        weight = (1.0 + math.log(count)) * idf.get(token, default_idf)
        idx = _hash_token(token)
        vec[idx] += weight

    norm = math.sqrt(sum(v * v for v in vec))
    if norm > 0:
        vec = [v / norm for v in vec]
    return vec


def _cosine(a: List[float], b: List[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


class VectorStore:
    def __init__(self):
        self.chunks: List[Dict[str, Any]] = []
        self.idf: Dict[str, float] = {}
        self._build_index()

    def _build_index(self):
        raw_items = []
        for doc in KNOWLEDGE_BASE:
            doc_chunks = chunk_document(doc)
            for c in doc_chunks:
                tokens = tokenize(f"{c['text']} {' '.join(doc['tags'])}")
                raw_items.append({
                    **c,
                    "tokens": tokens,
                })

        df: Dict[str, int] = {}
        for item in raw_items:
            for token in set(item["tokens"]):
                df[token] = df.get(token, 0) + 1

        total = len(raw_items)
        for token, count in df.items():
            self.idf[token] = math.log((total + 1.0) / (count + 0.5))

        self.chunks = []
        for item in raw_items:
            self.chunks.append({
                "id": item["id"],
                "docId": item["docId"],
                "title": item["title"],
                "source": item["source"],
                "tags": item["tags"],
                "text": item["text"],
                "vector": _embed(item["tokens"], self.idf),
            })


_store_instance: VectorStore = None


def get_vector_store() -> VectorStore:
    global _store_instance
    if _store_instance is None:
        _store_instance = VectorStore()
    return _store_instance


def retrieve(query: str, k: int = 5) -> List[Dict[str, Any]]:
    store = get_vector_store()
    query_tokens = tokenize(query)
    query_vec = _embed(query_tokens, store.idf)

    scored = []
    for chunk in store.chunks:
        score = _cosine(query_vec, chunk["vector"])
        if score > 0.02:
            scored.append({
                "chunk": chunk,
                "score": score,
            })

    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored[:k]


def format_context(results: List[Dict[str, Any]]) -> str:
    blocks = []
    for i, r in enumerate(results, 1):
        c = r["chunk"]
        blocks.append(f"[{i}] {c['title']} ({c['source']})\n{c['text']}")
    return "\n\n".join(blocks)


def citations_of(results: List[Dict[str, Any]]) -> List[str]:
    citations = []
    seen = set()
    for r in results:
        c = r["chunk"]
        cite = f"{c['title']} — {c['source']}"
        if cite not in seen:
            seen.add(cite)
            citations.append(cite)
    return citations


def knowledge_base_stats() -> Dict[str, int]:
    store = get_vector_store()
    return {
        "documents": len(KNOWLEDGE_BASE),
        "chunks": len(store.chunks),
        "dimensions": DIM,
    }
