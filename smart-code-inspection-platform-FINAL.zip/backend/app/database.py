import json
import sqlite3
from typing import List, Optional, Dict, Any
from .config import DATABASE_PATH
from .models.schemas import AnalysisRecord


def get_db_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS analyses (
            id TEXT PRIMARY KEY,
            created_at INTEGER NOT NULL,
            filename TEXT NOT NULL,
            language TEXT NOT NULL,
            code TEXT NOT NULL,
            verdict TEXT NOT NULL,
            overall_health INTEGER NOT NULL,
            security_score INTEGER NOT NULL,
            quality_score INTEGER NOT NULL,
            maintainability_score INTEGER NOT NULL,
            complexity TEXT NOT NULL,
            record_json TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


def save_analysis(record: AnalysisRecord):
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT OR REPLACE INTO analyses (
            id, created_at, filename, language, code, verdict,
            overall_health, security_score, quality_score, maintainability_score,
            complexity, record_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        record.id,
        record.createdAt,
        record.submission.filename,
        record.submission.language,
        record.code,
        record.summary.verdict,
        record.metrics.overallHealth,
        record.metrics.securityScore,
        record.metrics.qualityScore,
        record.metrics.maintainabilityScore,
        record.metrics.complexity,
        json.dumps(record.model_dump())
    ))
    conn.commit()
    conn.close()


def get_analysis(record_id: str) -> Optional[AnalysisRecord]:
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT record_json FROM analyses WHERE id = ?", (record_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        data = json.loads(row["record_json"])
        return AnalysisRecord(**data)
    return None


def list_analyses() -> List[AnalysisRecord]:
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT record_json FROM analyses ORDER BY created_at DESC")
    rows = cursor.fetchall()
    conn.close()
    results = []
    for r in rows:
        try:
            results.append(AnalysisRecord(**json.loads(r["record_json"])))
        except Exception:
            pass
    return results


def delete_analysis(record_id: str) -> bool:
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM analyses WHERE id = ?", (record_id,))
    affected = cursor.rowcount
    conn.commit()
    conn.close()
    return affected > 0


def clear_all_analyses() -> bool:
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM analyses")
    conn.commit()
    conn.close()
    return True
