from typing import List, Dict, Any

SAMPLES: List[Dict[str, str]] = [
    {
        "id": "python-banking",
        "label": "Python — banking service (SQLi, secrets, shell)",
        "filename": "banking_service.py",
        "language": "Python",
        "code": '''import os
import hashlib
import random
import sqlite3
import subprocess

API_KEY = "sk_live_9d8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b"
DB_PATH = "bank.db"


class AccountService:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH)

    def find_user(self, username):
        cursor = self.conn.cursor()
        query = "SELECT id, balance FROM accounts WHERE username = '" + username + "'"
        cursor.execute(query)
        return cursor.fetchone()

    def hash_password(self, password):
        return hashlib.md5(password.encode()).hexdigest()

    def new_session_token(self):
        return str(random.randint(100000, 999999))

    def transfer(self, user, amount, to_account):
        row = self.find_user(user)
        if row is None:
            return False
        cursor = self.conn.cursor()
        cursor.execute(f"UPDATE accounts SET balance = balance - {amount} WHERE username = '{user}'")
        cursor.execute(f"UPDATE accounts SET balance = balance + {amount} WHERE id = {to_account}")
        self.conn.commit()
        print("transferred", amount, "api_key", API_KEY)
        return True

    def export_statement(self, user, fmt):
        os.system("pdfgen --user " + user + " --format " + fmt)

    def run_report(self, expression):
        return eval(expression)

    def backup(self):
        try:
            subprocess.call("tar -czf backup.tgz " + DB_PATH, shell=True)
        except Exception:
            pass
''',
    },
    {
        "id": "java-login",
        "label": "Java — login controller (SQLi, weak crypto, broad catch)",
        "filename": "LoginController.java",
        "language": "Java",
        "code": '''package com.example.auth;

import java.sql.*;
import java.security.MessageDigest;
import java.util.Random;

public class LoginController {

    private static final String DB_PASSWORD = "Adm1nP@ssw0rd2024";
    private Connection connection;

    public boolean login(String username, String password) {
        try {
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM users WHERE username = '" + username +
                         "' AND password = '" + hash(password) + "'";
            ResultSet rs = statement.executeQuery(sql);
            if (rs.next()) {
                System.out.println("Login ok for " + username + " password " + password);
                return true;
            }
        } catch (Exception e) {
        }
        return false;
    }

    private String hash(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            byte[] out = digest.digest(value.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : out) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    public String createResetToken() {
        Random random = new Random();
        return Long.toString(random.nextLong(), 36);
    }

    public void deleteUser(String userId) {
        try {
            Statement st = connection.createStatement();
            st.executeUpdate("DELETE FROM users WHERE id = " + userId);
        } catch (SQLException e) {
        }
    }
}
''',
    },
    {
        "id": "python-clean",
        "label": "Python — hardened version (control sample)",
        "filename": "secure_accounts.py",
        "language": "Python",
        "code": '''import os
import secrets
import sqlite3

from argon2 import PasswordHasher

_hasher = PasswordHasher()


def get_connection() -> sqlite3.Connection:
    """Open a connection using a path supplied by configuration, not source."""
    return sqlite3.connect(os.environ["ACCOUNTS_DB_PATH"])


def find_user(conn: sqlite3.Connection, username: str):
    cursor = conn.cursor()
    cursor.execute("SELECT id, balance FROM accounts WHERE username = ?", (username,))
    return cursor.fetchone()


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def new_session_token() -> str:
    return secrets.token_urlsafe(32)


def transfer(conn: sqlite3.Connection, actor_id: int, amount: int, to_account: int) -> bool:
    if amount <= 0:
        raise ValueError("amount must be positive")
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE accounts SET balance = balance - ? WHERE id = ? AND balance >= ?",
        (amount, actor_id, amount),
    )
    if cursor.rowcount != 1:
        conn.rollback()
        return False
    cursor.execute("UPDATE accounts SET balance = balance + ? WHERE id = ?", (amount, to_account))
    conn.commit()
    return True
''',
    },
]
