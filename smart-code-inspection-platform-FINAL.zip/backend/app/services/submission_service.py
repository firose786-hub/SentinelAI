import ast
import time
import uuid
from typing import Optional, List
from ..models.schemas import SubmissionResult

EXTENSION_MAP = {
    "py": "Python",
    "pyw": "Python",
    "java": "Java",
    "js": "JavaScript",
    "jsx": "JavaScript",
    "ts": "TypeScript",
    "tsx": "TypeScript",
    "c": "C",
    "h": "C",
    "cpp": "C++",
    "cc": "C++",
    "cxx": "C++",
    "hpp": "C++",
}

ACCEPTED_EXTENSIONS = [f".{e}" for e in EXTENSION_MAP.keys()]


def detect_language(code: str, filename: Optional[str] = None) -> str:
    if filename and "." in filename:
        ext = filename.split(".")[-1].lower()
        if ext in EXTENSION_MAP:
            return EXTENSION_MAP[ext]

    src = code[:4000]
    import re
    if re.search(r"^\s*(from\s+\S+\s+import|import\s+\w+)\s*$", src, re.MULTILINE) and re.search(r":\s*$", src, re.MULTILINE):
        return "Python"
    if re.search(r"\bdef\s+\w+\s*\(.*\)\s*:", src) or re.search(r"\bself\b", src):
        return "Python"
    if re.search(r"\b(public|private|protected)\s+(static\s+)?(class|void|int|String)\b", src):
        return "Java"
    if re.search(r"\bpackage\s+[\w.]+;", src):
        return "Java"
    if re.search(r"#include\s*[<\"]", src):
        return "C++" if re.search(r"\b(std::|namespace|class\s+\w+\s*\{)", src) else "C"
    if re.search(r"\b(interface|type)\s+\w+\s*[={]", src) or re.search(r":\s*(string|number|boolean)\b", src):
        return "TypeScript"
    if re.search(r"\b(const|let|function|=>)\b", src):
        return "JavaScript"

    return "Unknown"


def _check_balanced_delimiters(code: str) -> List[str]:
    errors: List[str] = []
    pairs = {")": "(", "]": "[", "}": "{"}
    stack = []
    line = 1
    in_string = None
    in_line_comment = False
    in_block_comment = False

    i = 0
    length = len(code)
    while i < length:
        ch = code[i]
        next_ch = code[i + 1] if i + 1 < length else ""

        if ch == "\n":
            line += 1
            in_line_comment = False
            i += 1
            continue

        if in_line_comment:
            i += 1
            continue

        if in_block_comment:
            if ch == "*" and next_ch == "/":
                in_block_comment = False
                i += 2
                continue
            i += 1
            continue

        if in_string:
            if ch == "\\":
                i += 2
                continue
            elif ch == in_string:
                in_string = None
            i += 1
            continue

        if ch == "#" or (ch == "/" and next_ch == "/"):
            in_line_comment = True
            i += 1
            continue

        if ch == "/" and next_ch == "*":
            in_block_comment = True
            i += 2
            continue

        if ch in ('"', "'"):
            in_string = ch
            i += 1
            continue

        if ch in ("(", "[", "{"):
            stack.append((ch, line))
        elif ch in pairs:
            if not stack:
                errors.append(f"Unmatched '{ch}' on line {line}.")
            else:
                top_ch, top_line = stack.pop()
                if top_ch != pairs[ch]:
                    errors.append(f"Mismatched closing '{ch}' on line {line} for '{top_ch}' opened on line {top_line}.")

        i += 1

    if in_string:
        errors.append("Unterminated string literal.")
    for open_ch, open_line in stack:
        errors.append(f"Unclosed '{open_ch}' opened on line {open_line}.")

    return errors[:5]


def validate_python_syntax(code: str) -> List[str]:
    errors: List[str] = []
    try:
        ast.parse(code)
    except SyntaxError as e:
        line_info = f"Line {e.lineno}" if e.lineno else "Syntax error"
        msg = f"{line_info}: {e.msg}"
        errors.append(msg)
    except Exception as e:
        errors.append(f"Parsing error: {str(e)}")

    # Check for missing colons on block statements or mixed indentation if ast didn't fail
    if not errors:
        lines = code.split("\n")
        import re
        for idx, raw in enumerate(lines, 1):
            text = raw.split("#")[0].rstrip()
            if not text.strip():
                continue
            if re.match(r"^\s*(def|class|if|elif|else|for|while|try|except|finally|with|match|case)\b", text):
                if not text.endswith(":") and not text.endswith("\\") and not re.search(r"[([{,]$", text):
                    errors.append(f"Line {idx}: block statement is missing a trailing ':'.")
            if "\t" in raw and raw.startswith(" "):
                errors.append(f"Line {idx}: mixed tabs and spaces in indentation.")

    return errors[:6]


def validate_java_syntax(code: str) -> List[str]:
    errors = _check_balanced_delimiters(code)
    import re

    if not re.search(r"\b(class|interface|enum|record)\s+\w+", code):
        errors.append("No class, interface, enum or record declaration found.")

    # Try javalang parser for robust structural syntax verification
    try:
        import javalang
        tokens = list(javalang.tokenizer.tokenize(code))
        parser = javalang.parser.Parser(tokens)
        parser.parse()
    except Exception as e:
        err_str = str(e)
        if "Expected" in err_str or "SyntaxError" in err_str or "ParserError" in err_str:
            errors.append(f"Java parser: {err_str}")

    # Also perform statement semicolon checks
    lines = code.split("\n")
    for idx, raw in enumerate(lines, 1):
        text = raw.split("//")[0].strip()
        if not text or re.search(r"[{};:]$", text) or text.startswith("@") or text.startswith("*"):
            continue
        if re.match(r"^(import|package)\s", text):
            errors.append(f"Line {idx}: '{text.split()[0]}' statement must end with ';'.")
            continue
        if re.match(r"^\s*(return|throw|break|continue)\b", text) or re.match(r"^\w[\w<>\[\].]*\s+\w+\s*=", text):
            if not re.search(r"[,+\-*/&|(\\]$", text):
                errors.append(f"Line {idx}: statement may be missing ';'.")

    # De-duplicate while preserving order
    seen = set()
    deduped = []
    for err in errors:
        if err not in seen:
            seen.add(err)
            deduped.append(err)
    return deduped[:6]


def validate_submission(
    code: str,
    filename: Optional[str] = "snippet.py",
    requested_language: Optional[str] = "Auto-detect",
) -> SubmissionResult:
    auto = not requested_language or requested_language == "Auto-detect"
    language = detect_language(code, filename) if auto else requested_language

    syntax_errors: List[str] = []
    if not code.strip():
        syntax_errors = ["Submission is empty."]
    elif language == "Python":
        syntax_errors = validate_python_syntax(code)
    elif language == "Java":
        syntax_errors = validate_java_syntax(code)
    else:
        syntax_errors = _check_balanced_delimiters(code)

    sub_id = f"sub_{int(time.time()*1000):x}_{uuid.uuid4().hex[:6]}"

    return SubmissionResult(
        id=sub_id,
        filename=filename or "snippet",
        language=language,
        languageAutoDetected=auto,
        lineCount=len(code.split("\n")),
        charCount=len(code),
        syntaxValid=(len(syntax_errors) == 0),
        syntaxErrors=syntax_errors,
    )
